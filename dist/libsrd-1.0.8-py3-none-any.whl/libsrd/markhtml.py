import markdown
import os
import sys

def CreateHtml(path):
    outputpath = os.path.splitext(path)[0]+'.html'
    markdown.markdownFromFile(input=path, output=outputpath)

def _script():
    if len(sys.argv) == 2:
        CreateHtml(sys.argv[1])
    else:
        print("Expected one arguments (InputFile)")